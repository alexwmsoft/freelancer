module.exports = {
  project:{
    android: {},
    ios: {},
  },
  assets: ["./src/common/fonts"]
};
