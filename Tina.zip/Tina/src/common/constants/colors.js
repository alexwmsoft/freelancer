export default {
  "ordinateur": [
    "#28c7ee", "#76dcf3", "#8be0f5", "#d4f4fc"
  ],
  "periferique": [
    "#05d7ca", "#7cf1e9", "#9ffaf3", "#ccf7f4"
  ],
  "logiciel": [
    "#7f68ff", "#9e8dff", "#cec5fe", "#e9e5fb"
  ],
  "internet": [
    "#0059ff", "#77a6fe", "#98b9fe", "#edf3ff"
  ],
  "astuce": [
    '#ffad71', '#ffc9a1', '#ffe9d9', "#ffefe2"
  ],
}